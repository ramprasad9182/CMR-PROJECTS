from odoo import models, api, _
from odoo.exceptions import ValidationError

class ResPartner(models.Model):
    _inherit = 'res.partner'

    @api.constrains('name')
    def _check_duplicate_name_case_insensitive_vendor(self):
        for rec in self:
            if rec.name:
                normalized_name = rec.name.strip().lower()
                duplicates = self.env['res.partner'].search([
                    ('id', '!=', rec.id),
                ])
                for dup in duplicates:
                    if dup.name and dup.name.strip().lower() == normalized_name:
                        raise ValidationError(
                            f"A Vendor named '{rec.name}' already exists')."
                        )