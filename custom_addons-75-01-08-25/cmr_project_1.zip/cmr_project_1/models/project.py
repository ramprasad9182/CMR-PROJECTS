from odoo import fields,models,api,_
from odoo.exceptions import ValidationError, UserError


class Project(models.Model):
    _inherit = "project.project"

    receipt_type_id = fields.Many2one('stock.picking.type', string='Receipt Operation Type')
    delivery_type_id = fields.Many2one('stock.picking.type', string='Delivery Operation Type')
    internal_type_id = fields.Many2one('stock.picking.type', string='Internal Transfer Type')
    manufacturing_type_id = fields.Many2one('stock.picking.type', string='Manufacturing Type')
    repair_type_id = fields.Many2one('stock.picking.type', string='Repair Type')

    @api.model
    def create(self, vals):
        res = super().create(vals)

        if len(res.tag_ids) > 1:
            raise ValidationError("You can select only one value for Tags.")

        location = self.env['stock.location'].create({
            'name': res.name,
            'usage': 'internal',
        })

        def _create_sequence(name, code):
            return self.env['ir.sequence'].create({
                'name': name,
                'code': code,
                'prefix': code.upper() + '/',
                'padding': 4,
                'number_next': 1,
            })

        picking_obj = self.env['stock.picking.type']

        res.receipt_type_id = picking_obj.create({
            'name': f'{res.name}: Receipts',
            'code': 'incoming',
            'sequence_code': f'{res.name.lower().replace(" ", "_")}_incoming',
            'default_location_src_id': self.env.ref('stock.stock_location_suppliers').id,
            'default_location_dest_id': location.id,
            'sequence_id': _create_sequence(f'{res.name} Incoming', f'{res.name.lower()}_incoming').id,
        })

        res.delivery_type_id = picking_obj.create({
            'name': f'{res.name}: Delivery',
            'code': 'outgoing',
            'sequence_code': f'{res.name.lower().replace(" ", "_")}_outgoing',
            'default_location_src_id': location.id,
            'default_location_dest_id': self.env.ref('stock.stock_location_customers').id,
            'sequence_id': _create_sequence(f'{res.name} Outgoing', f'{res.name.lower()}_outgoing').id,
        })

        res.internal_type_id = picking_obj.create({
            'name': f'{res.name}: Internal Transfer',
            'code': 'internal',
            'sequence_code': f'{res.name.lower().replace(" ", "_")}_internal',
            'default_location_src_id': location.id,
            'default_location_dest_id': location.id,
            'sequence_id': _create_sequence(f'{res.name} Internal', f'{res.name.lower()}_internal').id,
        })

        res.manufacturing_type_id = picking_obj.create({
            'name': f'{res.name}: Manufacturing',
            'code': 'mrp_operation',
            'sequence_code': f'{res.name.lower().replace(" ", "_")}_manufacturing',
            'default_location_src_id': location.id,
            'default_location_dest_id': location.id,
            'sequence_id': _create_sequence(f'{res.name} Manufacturing', f'{res.name.lower()}_manufacturing').id,
        })

        res.repair_type_id = picking_obj.create({
            'name': f'{res.name}: Repairs',
            'code': 'repair_operation',
            'sequence_code': f'{res.name.lower().replace(" ", "_")}_repairs',
            'default_location_src_id': location.id,
            'default_location_dest_id': location.id,
            'sequence_id': _create_sequence(f'{res.name} Repairs', f'{res.name.lower()}_repairs').id,
        })

        return res

    # @api.model
    # def create(self, vals_list):
    #     res = super(Project, self).create(vals_list)
    #     if len(self.tag_ids) > 1:
    #         raise ValidationError("You can select, only one value for Tags")
    #     return res

    # @api.onchange('project_estimate_value', 'task_ids')
    # def _check_project_estimate_value(self):
    #     for project in self:
    #         if project.task_ids:
    #             total_task_estimate = sum(project.task_ids.mapped('nhcl_estimate_value'))
    #             if project.project_estimate_value < total_task_estimate:
    #                 raise ValidationError(
    #                     "The project's estimated value is less than the total estimated value of its tasks. "
    #                     "Please adjust the project's estimated value.")


class Task(models.Model):
    _inherit = "project.task"

    nhcl_estimate_qty = fields.Float(string="Estimate Qty", tracking=True)
    nhcl_estimate_value = fields.Float(string="Estimate Value", tracking=True)
    nhcl_product_id = fields.Many2one('product.product', string='Product')
    nhcl_project_product_ids = fields.One2many('nhcl.project.product','nhcl_task_id')

###############################################################
    @api.constrains('name', 'project_id')
    def _check_unique_task_name_in_project(self):
        for task in self:
            normalized_name = task.name.strip().lower()
            duplicate = self.env['project.task'].search([
                ('id', '!=', task.id),
                ('project_id', '=', task.project_id.id)
            ])
            for other_task in duplicate:
                if other_task.name.strip().lower() == normalized_name:
                    raise ValidationError("Task name must be unique (case-insensitive) within the same project.")
######################################################################################

    def _check_estimated_values(self):
        """ Validate estimated values for subtasks and project budget """
        for task in self:
            # Validation for subtasks
            if task.parent_id and task.parent_id.nhcl_project_product_ids:
                task_parent_estimate_value = sum(
                    task.parent_id.nhcl_project_product_ids.mapped('nhcl_product_estimate_value'))
                total_subtask_estimate = sum(
                    task.parent_id.child_ids.mapped('nhcl_project_product_ids.nhcl_product_estimate_value'))
                if total_subtask_estimate > task_parent_estimate_value:
                    raise ValidationError(
                        "The total estimated value of subtasks exceeds the parent task's estimated value. "
                        "Please adjust the parent task's estimated value."
                    )
            # Validation for project and tasks
            if task.project_id and task.project_id.total_budget_amount:
                total_task_estimate = sum(
                    task.project_id.task_ids.mapped('nhcl_project_product_ids.nhcl_product_estimate_value'))
                if total_task_estimate > task.project_id.total_budget_amount:
                    raise ValidationError(
                        "The total estimated value of tasks exceeds the project's estimated value. "
                        "Please adjust the project's estimated value."
                    )

    @api.model_create_multi
    def create(self, vals_list):
        res = super(Task, self).create(vals_list)
        for record in res:
            if record.project_id:
                record.tag_ids = [(6, 0, record.project_id.tag_ids.ids)]
        self._check_estimated_values()
        return res

    def write(self, vals):
        res = super(Task, self).write(vals)
        if len(self.tag_ids) > 1:
            raise ValidationError("You can select, only one value for Project Type")
        self._check_estimated_values()
        return res


class ApprovalRequest(models.Model):
    _inherit = 'approval.request'

    nhcl_project_id = fields.Many2one('project.project', 'Project', required=True, readonly=True, copy=False, domain="['|', ('company_id', '=', False), ('company_id', '=?',  company_id)]", index=True, change_default=True)

#########################################################################################
    vendor_id = fields.Many2one('res.partner', string='Vendor')
    street = fields.Char(related='vendor_id.street', string='Street')
    street2 = fields.Char(related='vendor_id.street2', string='Street2')
    city = fields.Char(related='vendor_id.city', string='City')
    state_id = fields.Many2one('res.country.state', related='vendor_id.state_id', string='State')
    zip = fields.Char(related='vendor_id.zip', string='ZIP')
    country_id = fields.Many2one('res.country', related='vendor_id.country_id', string='Country')
    # user_accessible = fields.Boolean(
    #     string='User Accessible',
    #     compute='_compute_user_accessible',
    #     store=True
    # )

    can_edit_vendor = fields.Boolean(
        string="Can Edit Vendor",
        compute="_compute_can_edit_vendor",
        store=False
    )
    approval_product_line_ids = fields.One2many(
        'approval.product.line', 'approval_request_id', string='Product Lines'
    )

    @api.depends('approver_ids')
    def _compute_can_edit_vendor(self):
        for rec in self:
            rec.can_edit_vendor = self.env.uid in rec.approver_ids.mapped('user_id').ids

    # @api.constrains('vendor_id', 'request_status')
    # def _check_vendor_required(self):
    #     for rec in self:
    #         if rec.request_status == 'approved' and not rec.vendor_id:
    #             raise ValidationError(_("Vendor is required"))

    def action_approve(self, approver=None):
        for request in self:
            for line in request.approval_product_line_ids:
                if not line.unit_price or line.unit_price == 0.00:
                    raise ValidationError(_("Unit price is required for all product lines before approval."))
                if not request.vendor_id:
                    raise ValidationError(_("Vendor is required before approval."))
        res = super(ApprovalRequest, self).action_approve(approver=approver)
        return res

    # def action_create_purchase_orders(self):
    #     """ Create and/or modify Purchase Orders. """
    #     self.ensure_one()
    #
    #     # No longer use _check_products_vendor(), instead use the vendor_id from the approval request
    #     vendor = self.vendor_id
    #     if not vendor:
    #         raise UserError("Please select a vendor for this approval request.")
    #
    #     for line in self.product_line_ids:
    #         # Now use the vendor_id directly from the approval.request instead of checking from product line
    #         seller = line.product_id.with_company(line.company_id)._select_seller(
    #             quantity=line.po_uom_qty,
    #             uom_id=line.product_id.uom_po_id,
    #             partner_id=vendor,  # Pass the selected vendor
    #         )
    #
    #         # Now vendor is always taken from self.vendor_id
    #         po_domain = line._get_purchase_orders_domain(vendor)
    #         purchase_orders = self.env['purchase.order'].search(po_domain)
    #
    #         if purchase_orders:
    #             # Existing RFQ found: check if we must modify an existing purchase order line or create a new one.
    #             purchase_line = self.env['purchase.order.line'].search([(
    #                 'order_id', 'in', purchase_orders.ids),
    #                 ('product_id', '=', line.product_id.id),
    #                 ('product_uom', '=', line.product_id.uom_po_id.id),
    #             ], limit=1)
    #             purchase_order = self.env['purchase.order']
    #             if purchase_line:
    #                 # Compatible PO line found, only update the quantity.
    #                 line.purchase_order_line_id = purchase_line.id
    #                 purchase_line.product_qty = line.po_uom_qty
    #                 purchase_order = purchase_line.order_id
    #             else:
    #                 # No purchase order line found, create one.
    #                 purchase_order = purchase_orders[0]
    #                 po_line_vals = self.env['purchase.order.line']._prepare_purchase_order_line(
    #                     line.product_id,
    #                     line.quantity,
    #                     line.product_uom_id,
    #                     line.company_id,
    #                     seller,
    #                     purchase_order,
    #                 )
    #
    #                 # Override default price with unit_price from approval.product.line
    #                 po_line_vals['price_unit'] = line.unit_price  # Use custom unit_price
    #
    #                 new_po_line = self.env['purchase.order.line'].create(po_line_vals)
    #                 line.purchase_order_line_id = new_po_line.id
    #                 purchase_order.order_line = [(4, new_po_line.id)]
    #
    #             # Add the request name on the purchase order `origin` field.
    #             new_origin = set([self.name])
    #             if purchase_order.origin:
    #                 missing_origin = new_origin - set(purchase_order.origin.split(', '))
    #                 if missing_origin:
    #                     purchase_order.write({'origin': purchase_order.origin + ', ' + ', '.join(missing_origin)})
    #             else:
    #                 purchase_order.write({'origin': ', '.join(new_origin)})
    #         else:
    #             # No RFQ found: create a new one.
    #             po_vals = line._get_purchase_order_values(vendor)
    #             new_purchase_order = self.env['purchase.order'].create(po_vals)
    #             po_line_vals = self.env['purchase.order.line']._prepare_purchase_order_line(
    #                 line.product_id,
    #                 line.po_uom_qty,
    #                 line.product_uom_id,
    #                 line.company_id,
    #                 seller,
    #                 new_purchase_order,
    #             )
    #
    #             # Override default price with unit_price from approval.product.line
    #             po_line_vals['price_unit'] = line.unit_price  # Use custom unit_price
    #
    #             new_po_line = self.env['purchase.order.line'].create(po_line_vals)
    #             line.purchase_order_line_id = new_po_line.id
    #             new_purchase_order.order_line = [(4, new_po_line.id)]

    def action_create_purchase_orders(self):
        """ Create and/or modify Purchase Orders. """
        self.ensure_one()

        vendor = self.vendor_id
        if not vendor:
            raise UserError("Please select a vendor for this approval request.")

        for line in self.product_line_ids:
            # Skip lines already linked to a purchase order line
            if line.purchase_order_line_id:
                continue

            # Find seller info for the selected vendor
            seller = line.product_id.with_company(line.company_id)._select_seller(
                quantity=line.po_uom_qty,
                uom_id=line.product_id.uom_po_id,
                partner_id=vendor,
            )

            # Only search for draft POs related to this specific approval request
            po_domain = [
                ('partner_id', '=', vendor.id),
                ('state', '=', 'draft'),
                ('origin', 'ilike', self.name),  # Only reuse if it came from this approval
            ]
            purchase_orders = self.env['purchase.order'].search(po_domain)

            purchase_order = purchase_orders[:1]  # Use the first matching PO if any
            if purchase_order:
                # Check if this product already exists in the draft PO
                purchase_line = self.env['purchase.order.line'].search([
                    ('order_id', '=', purchase_order.id),
                    ('product_id', '=', line.product_id.id),
                    ('product_uom', '=', line.product_id.uom_po_id.id),
                ], limit=1)

                if purchase_line:
                    # Update quantity if line exists
                    purchase_line.product_qty = line.po_uom_qty
                    line.purchase_order_line_id = purchase_line.id
                else:
                    # Create new PO line
                    po_line_vals = self.env['purchase.order.line']._prepare_purchase_order_line(
                        line.product_id,
                        line.po_uom_qty,
                        line.product_uom_id,
                        line.company_id,
                        seller,
                        purchase_order,
                    )
                    po_line_vals['price_unit'] = line.unit_price
                    new_po_line = self.env['purchase.order.line'].create(po_line_vals)
                    line.purchase_order_line_id = new_po_line.id
                    purchase_order.order_line = [(4, new_po_line.id)]
            else:
                # No draft PO for this approval — create a new one
                po_vals = line._get_purchase_order_values(vendor)
                po_vals['origin'] = self.name  # set origin to approval name
                new_purchase_order = self.env['purchase.order'].create(po_vals)

                po_line_vals = self.env['purchase.order.line']._prepare_purchase_order_line(
                    line.product_id,
                    line.po_uom_qty,
                    line.product_uom_id,
                    line.company_id,
                    seller,
                    new_purchase_order,
                )
                po_line_vals['price_unit'] = line.unit_price
                new_po_line = self.env['purchase.order.line'].create(po_line_vals)
                line.purchase_order_line_id = new_po_line.id
                new_purchase_order.order_line = [(4, new_po_line.id)]


############################################################################################


class ApprovalProductLine(models.Model):
    _inherit = 'approval.product.line'

    nhcl_analytic_account_id = fields.Many2one('account.analytic.account',domain="[('company_id', '=?', company_id)]", ondelete='set null', compute='_compute_analytic_account_id', store=True, readonly=False, string="Analtyic Account")
    # custom_vendor_id = fields.Many2one(
    #     'res.partner',
    #     string='Vendor',
    #     related='approval_request_id.vendor_id',
    #     store=True,
    #     readonly=False  # Optional: set to True if you don’t want it to be edited manually
    # )
    unit_price=fields.Float(string="Unit Price")


    @api.depends('approval_request_id.nhcl_project_id')
    def _compute_analytic_account_id(self):
        for task in self:
            if task.approval_request_id.nhcl_project_id:
                task.nhcl_analytic_account_id = task.approval_request_id.nhcl_project_id.account_id
            else:
                task.nhcl_analytic_account_id = False



class BudgetAnalytic(models.Model):
    _inherit = "budget.analytic"
    _description = "Budget"

    nhcl_user_id = fields.Many2one('res.users', string="Manager", related="user_id.employee_parent_id.user_id")

    # def revise_the_budget(self):
    #     for rec in self.budget_line_ids:
    #         rec.write({'previous_planned_amount' : rec.planned_amount})
    #     self.write({'state': 'draft'})
    #
    # def action_budget_cancel(self):
    #     for rec in self.budget_line_ids:
    #         rec.write({'planned_amount': rec.previous_planned_amount})
    #     self.write({'state': 'cancel'})
    #
    # def send_msg_to_user(self, user_ids, author_id, body, name):
    #     """Send a message to users."""
    #     # Search for the existing channel, using the mail thread model
    #     mail_channel = self.env['discuss.channel'].search(
    #         [('name', '=', name), ('channel_partner_ids', 'in', user_ids)], limit=1)
    #
    #     if not mail_channel:
    #         # If no existing channel is found, create a new one
    #         mail_channel = self.env['discuss.channel'].create({
    #             'name': name,
    #             'channel_partner_ids': [(4, user_id) for user_id in user_ids],
    #             'channel_type': 'group',  # 'group' for discussion-based channel
    #         })
    #
    #     # Post the message in the channel using the mail.thread model
    #     mail_channel.message_post(
    #         author_id=author_id,
    #         body=body,
    #         message_type='comment',
    #         subtype_xmlid='mail.mt_comment'
    #     )
    #
    # def create_revised_budget(self):
    #     """Create a revised budget record and send notification to the assigned user."""
    #     for record in self:
    #         # Create the revised budget record
    #         self.env['nhcl.revised.budgets'].create({
    #             'project_name': record.name,  # Assuming 'name' field is the project name in crossovered.budget
    #             'planned_amount_revised': sum(line.planned_amount for line in record.budget_line_ids),
    #             'approver': record.nhcl_user_id.id,
    #         })
    #
    #         # Check if nhcl_user_id is set
    #         if not record.nhcl_user_id:
    #             raise ValidationError(_("You must assign a user before creating the revised budget."))
    #         # Prepare the message body
    #         body = _("The revised budget for project '%s' is waiting for your approval.") % (record.name)
    #         # Prepare the partner ID of the assigned user (from nhcl_user_id)
    #         partner_id = record.nhcl_user_id.partner_id.id
    #         # Send the notification to the assigned user
    #         self.send_msg_to_user([partner_id], self.env.user.partner_id.id, body, "Revised Budget")


class BudgetLine(models.Model):
    _inherit = 'budget.line'
    _description = "Budget Line"

    previous_planned_amount = fields.Monetary('Previous Planned Amount')


# class Nhclrevisedbudget(models.Model):
#     _name = "nhcl.revised.budgets"
#     _inherit = ['mail.thread', 'mail.activity.mixin']
#
#     state = fields.Selection([('draft', 'Draft'),('approved', 'Approved'), ('cancel','Cancel')],
#                              string='State', default='draft', tracking=True)
#     project_name = fields.Char('Project Name', tracking=True)
#     planned_amount_revised = fields.Float('Initial Budget Amount', tracking=True)
#     nhcl_planned_amount_revised = fields.Float('Revised Budget Amount', default=0.0, tracking=True)
#     approver = fields.Many2one('res.users', string="Approver")
#
#     def reset_to_draft(self):
#         self.write({'state':'draft'})
#
#     def cancel_revised(self):
#         self.write({'state': 'cancel'})
#
#     def approve_revised_amount(self):
#         """Approve the revised budget and update the planned_amount in the related budget lines."""
#         for record in self:
#             # Find the corresponding crossovered.budget.line based on project_name
#             crossovered_budget_lines = self.env['budget.line'].search([('name', '=', record.project_name)])
#             # If there are related budget lines, update their planned_amount
#             if crossovered_budget_lines:
#                 crossovered_budget_lines.write({'planned_amount': record.nhcl_planned_amount_revised})
#
#             # Update the state of the nhcl.revised.budgets record to 'approved'
#             record.write({'state': 'approved'})


class ProjectProduct(models.Model):
    _name = 'nhcl.project.product'

    nhcl_product_id = fields.Many2one('product.product', string="Product", copy=False)
    nhcl_product_categ_id = fields.Many2one('product.category', string="Product Category", copy=False,
                                            related='nhcl_product_id.categ_id', store=True)
    nhcl_product_estimate_qty = fields.Float(string="Estimate Qty", copy=False)
    nhcl_product_estimate_value = fields.Float(string="Estimate Value", tracking=True)
    nhcl_product_dummy_qty = fields.Float(string="D.Actual Qty", tracking=True, compute='_compute_actuals')
    nhcl_product_dummy_value = fields.Float(string="D.Actual Value", tracking=True, compute='_compute_actuals')
    nhcl_product_actual_qty = fields.Float(string="Actual Qty", tracking=True, copy=False)
    nhcl_product_actual_value = fields.Float(string="Actual Value", tracking=True, copy=False)
    nhcl_product_balance_qty = fields.Float(string="Balance Qty", tracking=True, copy=False,
                                            compute='nhcl_get_balance_qty')
    nhcl_product_balance_value = fields.Float(string="Balance Value", tracking=True, copy=False,
                                              compute='nhcl_get_balance_value')
    nhcl_task_id = fields.Many2one('project.task', string="Task")
    nhcl_project_id = fields.Many2one('project.project', string="Project", related='nhcl_task_id.project_id',
                                      store=True)
    nhcl_task_stage_id = fields.Many2one('project.task.type', string="Stage", related='nhcl_task_id.stage_id',
                                         store=True)
    nhcl_product_account_id = fields.Many2one('account.analytic.account', string="Account", copy=False,
                                              related='nhcl_task_id.project_id.account_id', store=True)

###############################################################################################
    @api.constrains('nhcl_product_id', 'nhcl_task_id')
    def _check_duplicate_variant(self):
        """Disallow exact variant duplicates (same product.product) in a task."""
        for rec in self:
            if rec.nhcl_task_id:
                product_ids = []
                duplicate_names = []

                # Loop through all lines of the task
                for line in rec.nhcl_task_id.nhcl_project_product_ids:
                    if line.id != rec.id and line.nhcl_product_id:
                        prod_id = line.nhcl_product_id.id
                        if prod_id in product_ids:
                            duplicate_names.append(line.nhcl_product_id.display_name)
                        else:
                            product_ids.append(prod_id)

                # Also check current record's product
                if rec.nhcl_product_id and rec.nhcl_product_id.id in product_ids:
                    duplicate_names.append(rec.nhcl_product_id.display_name)

                # If any duplicates found, raise error
                if duplicate_names:
                    names = ", ".join(set(duplicate_names))
                    raise ValidationError(
                        f"The following product variant(s) are added multiple times: {names}. Please select different products."
                    )
##################################################################################################
    def nhcl_get_bills(self):
        return {
            'name': _('Detail Operation'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move.line',
            'view_mode': 'tree',
            'view_id': self.env.ref('account.view_move_line_tree').id,
            'domain': [('product_id', '=', self.nhcl_product_id.id),
                       ('analytic_line_ids.auto_account_id', '=', self.nhcl_product_account_id.id)]
        }

    def nhcl_get_balance_qty(self):
        for rec in self:
            rec.nhcl_product_balance_qty = rec.nhcl_product_estimate_qty - rec.nhcl_product_actual_qty

    def nhcl_get_balance_value(self):
        for rec in self:
            rec.nhcl_product_balance_value = rec.nhcl_product_estimate_value - rec.nhcl_product_actual_value

    @api.depends('nhcl_task_id', 'nhcl_project_id')
    def _compute_actuals(self):
        for task in self:
            if task.nhcl_product_account_id:
                purchase_line = self.env['purchase.order.line'].search([
                    ('product_id', '=', task.nhcl_product_id.id),
                    ('order_id.state', '=', 'purchase')  # Consider only posted bills
                ])
                # print('found data',purchase_line,"///",purchase_line.filtered(lambda line: task.nhcl_product_account_id in line.purchase_many[0]))
                filtered_lines = purchase_line.filtered(
                    #     lambda line: line.analytic_distribution and
                    #                  task.nhcl_product_account_id.id == (line._get_analytic_account_ids() or [None])[0]
                    # )
                    lambda line: line.analytic_distribution and
                                 task.nhcl_product_account_id in [r for r in line.purchase_many])
                if not filtered_lines:
                    # print('satisfied')
                    # No valid move lines found
                    task.nhcl_product_dummy_qty = 0.0
                    task.nhcl_product_actual_qty = 0.0
                    task.nhcl_product_dummy_value = 0.0
                    task.nhcl_product_actual_value = 0.0
                else:
                    task.nhcl_product_dummy_qty = sum(filtered_lines.mapped('product_qty'))
                    task.nhcl_product_actual_qty = sum(filtered_lines.mapped('product_qty'))
                    task.nhcl_product_dummy_value = sum(filtered_lines.mapped('price_subtotal'))
                    task.nhcl_product_actual_value = sum(filtered_lines.mapped('price_subtotal'))
            else:
                task.nhcl_product_dummy_qty = 0.0
                task.nhcl_product_actual_qty = 0.0
                task.nhcl_product_dummy_value = 0.0
                task.nhcl_product_actual_value = 0.0

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(ProjectProduct, self).read_group(domain, fields, groupby, offset=offset, limit=limit,
                                                     orderby=orderby,
                                                     lazy=lazy)
        if 'nhcl_product_estimate_value' in fields:
            for line in res:
                if '__domain' in line:
                    lines = self.search(line['__domain'])
                    for record in line:
                        if record == 'nhcl_project_id':
                            project = self.env['project.project'].search([('id', '=', line['nhcl_project_id'][0])])
                            line['nhcl_product_estimate_value'] = project.total_planned_amount

        return res

