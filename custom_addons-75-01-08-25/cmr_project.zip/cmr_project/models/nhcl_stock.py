from odoo import fields, models, api, _


class Picking(models.Model):
    _inherit = "stock.picking"

    security_check = fields.Char(string="Security Inward", tracking=True, copy=False)