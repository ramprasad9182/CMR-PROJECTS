from odoo import fields,models,api,_
from odoo.exceptions import ValidationError


class Project(models.Model):
    _inherit = "project.project"

    @api.model
    def create(self, vals_list):
        res = super(Project, self).create(vals_list)
        if len(self.tag_ids) > 1:
            raise ValidationError("You can select, only one value for Tags")
        return res

    # @api.onchange('project_estimate_value', 'task_ids')
    # def _check_project_estimate_value(self):
    #     for project in self:
    #         if project.task_ids:
    #             total_task_estimate = sum(project.task_ids.mapped('nhcl_estimate_value'))
    #             if project.project_estimate_value < total_task_estimate:
    #                 raise ValidationError(
    #                     "The project's estimated value is less than the total estimated value of its tasks. "
    #                     "Please adjust the project's estimated value.")


class Task(models.Model):
    _inherit = "project.task"

    nhcl_estimate_qty = fields.Float(string="Estimate Qty", tracking=True)
    nhcl_estimate_value = fields.Float(string="Estimate Value", tracking=True)
    nhcl_product_id = fields.Many2one('product.product', string='Product')
    nhcl_project_product_ids = fields.One2many('nhcl.project.product','nhcl_task_id')

    def _check_estimated_values(self):
        """ Validate estimated values for subtasks and project budget """
        for task in self:
            # Validation for subtasks
            if task.parent_id and task.parent_id.nhcl_project_product_ids:
                task_parent_estimate_value = sum(
                    task.parent_id.nhcl_project_product_ids.mapped('nhcl_product_estimate_value'))
                total_subtask_estimate = sum(
                    task.parent_id.child_ids.mapped('nhcl_project_product_ids.nhcl_product_estimate_value'))
                if total_subtask_estimate > task_parent_estimate_value:
                    raise ValidationError(
                        "The total estimated value of subtasks exceeds the parent task's estimated value. "
                        "Please adjust the parent task's estimated value."
                    )
            # Validation for project and tasks
            if task.project_id and task.project_id.total_budget_amount:
                total_task_estimate = sum(
                    task.project_id.task_ids.mapped('nhcl_project_product_ids.nhcl_product_estimate_value'))
                if total_task_estimate > task.project_id.total_budget_amount:
                    raise ValidationError(
                        "The total estimated value of tasks exceeds the project's estimated value. "
                        "Please adjust the project's estimated value."
                    )

    @api.model_create_multi
    def create(self, vals_list):
        res = super(Task, self).create(vals_list)
        for record in res:
            if record.project_id:
                record.tag_ids = [(6, 0, record.project_id.tag_ids.ids)]
        self._check_estimated_values()
        return res

    def write(self, vals):
        res = super(Task, self).write(vals)
        if len(self.tag_ids) > 1:
            raise ValidationError("You can select, only one value for Project Type")
        self._check_estimated_values()
        return res


class ApprovalRequest(models.Model):
    _inherit = 'approval.request'

    nhcl_project_id = fields.Many2one('project.project', 'Project', required=True, readonly=True, copy=False, domain="['|', ('company_id', '=', False), ('company_id', '=?',  company_id)]", index=True, change_default=True)


class ApprovalProductLine(models.Model):
    _inherit = 'approval.product.line'

    nhcl_analytic_account_id = fields.Many2one('account.analytic.account',domain="[('company_id', '=?', company_id)]", ondelete='set null', compute='_compute_analytic_account_id', store=True, readonly=False, string="Analtyic Account")

    @api.depends('approval_request_id.nhcl_project_id')
    def _compute_analytic_account_id(self):
        for task in self:
            if task.approval_request_id.nhcl_project_id:
                task.nhcl_analytic_account_id = task.approval_request_id.nhcl_project_id.account_id
            else:
                task.nhcl_analytic_account_id = False


class BudgetAnalytic(models.Model):
    _inherit = "budget.analytic"
    _description = "Budget"

    nhcl_user_id = fields.Many2one('res.users', string="Manager", related="user_id.employee_parent_id.user_id")

    # def revise_the_budget(self):
    #     for rec in self.budget_line_ids:
    #         rec.write({'previous_planned_amount' : rec.planned_amount})
    #     self.write({'state': 'draft'})
    #
    # def action_budget_cancel(self):
    #     for rec in self.budget_line_ids:
    #         rec.write({'planned_amount': rec.previous_planned_amount})
    #     self.write({'state': 'cancel'})
    #
    # def send_msg_to_user(self, user_ids, author_id, body, name):
    #     """Send a message to users."""
    #     # Search for the existing channel, using the mail thread model
    #     mail_channel = self.env['discuss.channel'].search(
    #         [('name', '=', name), ('channel_partner_ids', 'in', user_ids)], limit=1)
    #
    #     if not mail_channel:
    #         # If no existing channel is found, create a new one
    #         mail_channel = self.env['discuss.channel'].create({
    #             'name': name,
    #             'channel_partner_ids': [(4, user_id) for user_id in user_ids],
    #             'channel_type': 'group',  # 'group' for discussion-based channel
    #         })
    #
    #     # Post the message in the channel using the mail.thread model
    #     mail_channel.message_post(
    #         author_id=author_id,
    #         body=body,
    #         message_type='comment',
    #         subtype_xmlid='mail.mt_comment'
    #     )
    #
    # def create_revised_budget(self):
    #     """Create a revised budget record and send notification to the assigned user."""
    #     for record in self:
    #         # Create the revised budget record
    #         self.env['nhcl.revised.budgets'].create({
    #             'project_name': record.name,  # Assuming 'name' field is the project name in crossovered.budget
    #             'planned_amount_revised': sum(line.planned_amount for line in record.budget_line_ids),
    #             'approver': record.nhcl_user_id.id,
    #         })
    #
    #         # Check if nhcl_user_id is set
    #         if not record.nhcl_user_id:
    #             raise ValidationError(_("You must assign a user before creating the revised budget."))
    #         # Prepare the message body
    #         body = _("The revised budget for project '%s' is waiting for your approval.") % (record.name)
    #         # Prepare the partner ID of the assigned user (from nhcl_user_id)
    #         partner_id = record.nhcl_user_id.partner_id.id
    #         # Send the notification to the assigned user
    #         self.send_msg_to_user([partner_id], self.env.user.partner_id.id, body, "Revised Budget")


class BudgetLine(models.Model):
    _inherit = 'budget.line'
    _description = "Budget Line"

    previous_planned_amount = fields.Monetary('Previous Planned Amount')


# class Nhclrevisedbudget(models.Model):
#     _name = "nhcl.revised.budgets"
#     _inherit = ['mail.thread', 'mail.activity.mixin']
#
#     state = fields.Selection([('draft', 'Draft'),('approved', 'Approved'), ('cancel','Cancel')],
#                              string='State', default='draft', tracking=True)
#     project_name = fields.Char('Project Name', tracking=True)
#     planned_amount_revised = fields.Float('Initial Budget Amount', tracking=True)
#     nhcl_planned_amount_revised = fields.Float('Revised Budget Amount', default=0.0, tracking=True)
#     approver = fields.Many2one('res.users', string="Approver")
#
#     def reset_to_draft(self):
#         self.write({'state':'draft'})
#
#     def cancel_revised(self):
#         self.write({'state': 'cancel'})
#
#     def approve_revised_amount(self):
#         """Approve the revised budget and update the planned_amount in the related budget lines."""
#         for record in self:
#             # Find the corresponding crossovered.budget.line based on project_name
#             crossovered_budget_lines = self.env['budget.line'].search([('name', '=', record.project_name)])
#             # If there are related budget lines, update their planned_amount
#             if crossovered_budget_lines:
#                 crossovered_budget_lines.write({'planned_amount': record.nhcl_planned_amount_revised})
#
#             # Update the state of the nhcl.revised.budgets record to 'approved'
#             record.write({'state': 'approved'})


class ProjectProduct(models.Model):
    _name = 'nhcl.project.product'

    nhcl_product_id = fields.Many2one('product.product', string="Product", copy=False)
    nhcl_product_categ_id = fields.Many2one('product.category', string="Product Category", copy=False,
                                            related='nhcl_product_id.categ_id', store=True)
    nhcl_product_estimate_qty = fields.Float(string="Estimate Qty", copy=False)
    nhcl_product_estimate_value = fields.Float(string="Estimate Value", tracking=True)
    nhcl_product_dummy_qty = fields.Float(string="D.Actual Qty", tracking=True, compute='_compute_actuals')
    nhcl_product_dummy_value = fields.Float(string="D.Actual Value", tracking=True, compute='_compute_actuals')
    nhcl_product_actual_qty = fields.Float(string="Actual Qty", tracking=True, copy=False)
    nhcl_product_actual_value = fields.Float(string="Actual Value", tracking=True, copy=False)
    nhcl_product_balance_qty = fields.Float(string="Balance Qty", tracking=True, copy=False,
                                            compute='nhcl_get_balance_qty')
    nhcl_product_balance_value = fields.Float(string="Balance Value", tracking=True, copy=False,
                                              compute='nhcl_get_balance_value')
    nhcl_task_id = fields.Many2one('project.task', string="Task")
    nhcl_project_id = fields.Many2one('project.project', string="Project", related='nhcl_task_id.project_id',
                                      store=True)
    nhcl_task_stage_id = fields.Many2one('project.task.type', string="Stage", related='nhcl_task_id.stage_id',
                                         store=True)
    nhcl_product_account_id = fields.Many2one('account.analytic.account', string="Account", copy=False,
                                              related='nhcl_task_id.project_id.account_id', store=True)

    def nhcl_get_bills(self):
        return {
            'name': _('Detail Operation'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move.line',
            'view_mode': 'tree',
            'view_id': self.env.ref('account.view_move_line_tree').id,
            'domain': [('product_id', '=', self.nhcl_product_id.id),
                       ('analytic_line_ids.auto_account_id', '=', self.nhcl_product_account_id.id)]
        }

    def nhcl_get_balance_qty(self):
        for rec in self:
            rec.nhcl_product_balance_qty = rec.nhcl_product_estimate_qty - rec.nhcl_product_actual_qty

    def nhcl_get_balance_value(self):
        for rec in self:
            rec.nhcl_product_balance_value = rec.nhcl_product_estimate_value - rec.nhcl_product_actual_value

    @api.depends('nhcl_task_id', 'nhcl_project_id')
    def _compute_actuals(self):
        for task in self:
            if task.nhcl_product_account_id:
                move_lines = self.env['account.move.line'].search([
                    ('product_id', '=', task.nhcl_product_id.id),
                    ('move_id.state', '=', 'posted')  # Consider only posted bills
                ])
                filtered_lines = move_lines.filtered(
                    lambda line: line.analytic_distribution and
                                 task.nhcl_product_account_id.id == (line._get_analytic_account_ids() or [None])[0]
                )
                if not filtered_lines:
                    # No valid move lines found
                    task.nhcl_product_dummy_qty = 0.0
                    task.nhcl_product_actual_qty = 0.0
                    task.nhcl_product_dummy_value = 0.0
                    task.nhcl_product_actual_value = 0.0
                else:
                    task.nhcl_product_dummy_qty = sum(filtered_lines.mapped('quantity'))
                    task.nhcl_product_actual_qty = sum(filtered_lines.mapped('quantity'))
                    task.nhcl_product_dummy_value = sum(filtered_lines.mapped('price_subtotal'))
                    task.nhcl_product_actual_value = sum(filtered_lines.mapped('price_subtotal'))
            else:
                task.nhcl_product_dummy_qty = 0.0
                task.nhcl_product_actual_qty = 0.0
                task.nhcl_product_dummy_value = 0.0
                task.nhcl_product_actual_value = 0.0

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(ProjectProduct, self).read_group(domain, fields, groupby, offset=offset, limit=limit,
                                                     orderby=orderby,
                                                     lazy=lazy)
        if 'nhcl_product_estimate_value' in fields:
            for line in res:
                if '__domain' in line:
                    lines = self.search(line['__domain'])
                    for record in line:
                        if record == 'nhcl_project_id':
                            project = self.env['project.project'].search([('id', '=', line['nhcl_project_id'][0])])
                            line['nhcl_product_estimate_value'] = project.total_planned_amount

        return res

